var NPMPackage = require('../../package.json');

module.exports = {
    release: 115,
    bookmarkletVersion: '0.5',
    version: NPMPackage.version
};
