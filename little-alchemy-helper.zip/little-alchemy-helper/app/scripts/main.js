var React = require('react'),
    App   = require('./components/App');

document.addEventListener('DOMContentLoaded', function () {
    React.render(<App/>, document.getElementById('react'));
});
