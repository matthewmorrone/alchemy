Little Alchemy Helper
=====================

Interactive app to help while you play the game Little Alchemy.   
It can be used inside the game with a bookmarklet

[DEMO](http://littlealchemyhelper.com/ "Little Alchemy Helper")
